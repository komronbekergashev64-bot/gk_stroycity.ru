import { motion } from 'motion/react';
import { Building, Home, Factory, Hammer, Ruler, ClipboardCheck } from 'lucide-react';
import { useState } from 'react';

export function Services() {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const services = [
    {
      icon: Building,
      title: 'Коммерческое строительство',
      description: 'Офисные здания, торговые центры и бизнес-комплексы под ключ',
      features: ['Проектирование', 'Строительство', 'Отделка'],
      color: '#1e3a5f',
    },
    {
      icon: Home,
      title: 'Жилищное строительство',
      description: 'Многоквартирные дома, таунхаусы и коттеджи премиум-класса',
      features: ['Планировка', 'Возведение', 'Сдача объекта'],
      color: '#e8725c',
    },
    {
      icon: Factory,
      title: 'Промышленные объекты',
      description: 'Складские комплексы, производственные помещения и логистические центры',
      features: ['Инженерия', 'Монтаж', 'Запуск'],
      color: '#1e3a5f',
    },
    {
      icon: Hammer,
      title: 'Реконструкция',
      description: 'Модернизация и капитальный ремонт существующих зданий',
      features: ['Оценка', 'Ремонт', 'Модернизация'],
      color: '#e8725c',
    },
    {
      icon: Ruler,
      title: 'Проектирование',
      description: 'Архитектурное и инженерное проектирование любой сложности',
      features: ['3D-визуализация', 'Документация', 'Согласование'],
      color: '#1e3a5f',
    },
    {
      icon: ClipboardCheck,
      title: 'Генеральный подряд',
      description: 'Полный цикл работ от идеи до сдачи объекта в эксплуатацию',
      features: ['Управление', 'Контроль', 'Гарантия'],
      color: '#e8725c',
    },
  ];

  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-block bg-[#e8725c]/10 text-[#e8725c] px-4 py-2 rounded-full text-sm font-semibold mb-4">
            Наши услуги
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-[#1e3a5f] mb-4">
            Комплексные решения
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Предоставляем полный спектр строительных услуг с гарантией качества и соблюдением сроков
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              onHoverStart={() => setHoveredIndex(index)}
              onHoverEnd={() => setHoveredIndex(null)}
              className="group relative bg-white rounded-2xl p-8 border-2 border-gray-100 hover:border-transparent hover:shadow-2xl transition-all duration-300"
            >
              {/* Hover Background */}
              <div
                className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{
                  background: `linear-gradient(135deg, ${service.color}05 0%, ${service.color}15 100%)`,
                }}
              ></div>

              <div className="relative z-10">
                {/* Icon */}
                <div
                  className="w-16 h-16 rounded-xl flex items-center justify-center mb-6 transition-all duration-300 group-hover:scale-110"
                  style={{
                    backgroundColor: hoveredIndex === index ? service.color : `${service.color}15`,
                  }}
                >
                  <service.icon
                    className="w-8 h-8 transition-colors duration-300"
                    style={{
                      color: hoveredIndex === index ? 'white' : service.color,
                    }}
                  />
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-[#1e3a5f] mb-3">{service.title}</h3>
                <p className="text-gray-600 mb-4">{service.description}</p>

                {/* Features */}
                <ul className="space-y-2">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                      <div
                        className="w-1.5 h-1.5 rounded-full"
                        style={{ backgroundColor: service.color }}
                      ></div>
                      {feature}
                    </li>
                  ))}
                </ul>

                {/* Arrow */}
                <div className="mt-6 flex items-center gap-2 text-sm font-semibold opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <span style={{ color: service.color }}>Узнать больше</span>
                  <motion.div
                    animate={hoveredIndex === index ? { x: [0, 5, 0] } : {}}
                    transition={{ duration: 1, repeat: Infinity }}
                  >
                    <svg
                      width="16"
                      height="16"
                      viewBox="0 0 16 16"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M3 8H13M13 8L9 4M13 8L9 12"
                        stroke={service.color}
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </motion.div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center mt-12"
        >
          <button
            onClick={() => {
              const element = document.querySelector('#contact');
              if (element) element.scrollIntoView({ behavior: 'smooth' });
            }}
            className="inline-flex items-center gap-2 bg-[#e8725c] text-white px-8 py-4 rounded-lg font-semibold hover:bg-[#d66650] transition-all hover:scale-105 shadow-lg"
          >
            Заказать консультацию
            <svg
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M4 10H16M16 10L11 5M16 10L11 15"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>
        </motion.div>
      </div>
    </section>
  );
}
