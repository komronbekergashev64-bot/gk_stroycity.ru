import { motion } from 'motion/react';
import { useState } from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { MapPin, Calendar, ExternalLink } from 'lucide-react';

export function Projects() {
  const [activeFilter, setActiveFilter] = useState('Все');

  const filters = ['Все', 'Жилые', 'Коммерческие', 'Промышленные'];

  const projects = [
    {
      id: 1,
      title: 'ЖК "Северная Звезда"',
      category: 'Жилые',
      location: 'Новосибирск, Октябрьский р-н',
      date: '2023',
      image: 'https://images.unsplash.com/photo-1599412965471-e5f860059f07?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBhcGFydG1lbnQlMjBidWlsZGluZyUyMGV4dGVyaW9yfGVufDF8fHx8MTc3MDIyNTY2NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      area: '45,000 м²',
      status: 'Завершен',
    },
    {
      id: 2,
      title: 'Бизнес-центр "Сибирь"',
      category: 'Коммерческие',
      location: 'Новосибирск, Центральный р-н',
      date: '2023',
      image: 'https://images.unsplash.com/photo-1641060272821-df59e2c0b5ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBvZmZpY2UlMjBpbnRlcmlvciUyMGFyY2hpdGVjdHVyZXxlbnwxfHx8fDE3NzAyNTQxNjd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      area: '12,000 м²',
      status: 'Завершен',
    },
    {
      id: 3,
      title: 'Складской комплекс "Логистика+"',
      category: 'Промышленные',
      location: 'Новосибирск, Калининский р-н',
      date: '2024',
      image: 'https://images.unsplash.com/photo-1659449082344-53f79e1e4198?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjBjcmFuZSUyMHNreWxpbmV8ZW58MXx8fHwxNzcwMjY1MjE4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      area: '28,000 м²',
      status: 'В процессе',
    },
    {
      id: 4,
      title: 'ЖК "Академический"',
      category: 'Жилые',
      location: 'Новосибирск, Советский р-н',
      date: '2024',
      image: 'https://images.unsplash.com/photo-1759300098758-5508ad068048?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXNpZGVudGlhbCUyMGNvbXBsZXglMjBidWlsZGluZ3xlbnwxfHx8fDE3NzAyNjUyMTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      area: '67,000 м²',
      status: 'В процессе',
    },
    {
      id: 5,
      title: 'ТЦ "Речной"',
      category: 'Коммерческие',
      location: 'Новосибирск, Кировский р-н',
      date: '2022',
      image: 'https://images.unsplash.com/photo-1748956628042-b73331e0b479?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBjb25zdHJ1Y3Rpb24lMjBzaXRlJTIwd29ya2Vyc3xlbnwxfHx8fDE3NzAyNjUyMTd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      area: '35,000 м²',
      status: 'Завершен',
    },
    {
      id: 6,
      title: 'Производственный цех "Технопарк"',
      category: 'Промышленные',
      location: 'Новосибирск, Заельцовский р-н',
      date: '2023',
      image: 'https://images.unsplash.com/photo-1765378025255-5c2ff04563f4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb25zdHJ1Y3Rpb24lMjBibHVlcHJpbnQlMjBwbGFuc3xlbnwxfHx8fDE3NzAyMjExMDN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      area: '18,000 м²',
      status: 'Завершен',
    },
  ];

  const filteredProjects = activeFilter === 'Все' 
    ? projects 
    : projects.filter(p => p.category === activeFilter);

  return (
    <section id="projects" className="py-20 bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-block bg-[#1e3a5f]/10 text-[#1e3a5f] px-4 py-2 rounded-full text-sm font-semibold mb-4">
            Портфолио
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-[#1e3a5f] mb-4">
            Наши проекты
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Реализованные и текущие проекты, демонстрирующие наш профессионализм
          </p>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex flex-wrap justify-center gap-4 mb-12"
        >
          {filters.map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                activeFilter === filter
                  ? 'bg-[#e8725c] text-white shadow-lg scale-105'
                  : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
              }`}
            >
              {filter}
            </button>
          ))}
        </motion.div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300"
            >
              {/* Image */}
              <div className="relative h-64 overflow-hidden">
                <ImageWithFallback
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                
                {/* Status Badge */}
                <div className="absolute top-4 right-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    project.status === 'Завершен'
                      ? 'bg-green-500 text-white'
                      : 'bg-yellow-500 text-white'
                  }`}>
                    {project.status}
                  </span>
                </div>

                {/* Hover Link */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <button className="bg-white text-[#1e3a5f] px-6 py-3 rounded-lg font-semibold flex items-center gap-2 hover:bg-[#e8725c] hover:text-white transition-colors">
                    Подробнее
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <div className="text-sm text-[#e8725c] font-semibold mb-2">{project.category}</div>
                <h3 className="text-xl font-bold text-[#1e3a5f] mb-3 group-hover:text-[#e8725c] transition-colors">
                  {project.title}
                </h3>

                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-[#e8725c]" />
                    <span>{project.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-[#e8725c]" />
                    <span>{project.date} • {project.area}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center mt-12"
        >
          <p className="text-gray-600 mb-6">
            Хотите увидеть больше наших работ или обсудить свой проект?
          </p>
          <button
            onClick={() => {
              const element = document.querySelector('#contact');
              if (element) element.scrollIntoView({ behavior: 'smooth' });
            }}
            className="inline-flex items-center gap-2 bg-[#1e3a5f] text-white px-8 py-4 rounded-lg font-semibold hover:bg-[#152d47] transition-all hover:scale-105 shadow-lg"
          >
            Связаться с нами
          </button>
        </motion.div>
      </div>
    </section>
  );
}