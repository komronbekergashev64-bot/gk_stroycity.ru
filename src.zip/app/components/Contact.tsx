import { motion } from 'motion/react';
import { useState } from 'react';
import { Phone, Mail, MapPin, Clock, Send } from 'lucide-react';

export function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    service: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    alert('Спасибо! Мы свяжемся с вами в ближайшее время.');
    setFormData({ name: '', phone: '', email: '', service: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const contactInfo = [
    {
      icon: Phone,
      title: 'Телефон',
      content: '+7 913 941 38 14',
      link: 'tel:+79139413814',
      color: '#e8725c',
    },
    {
      icon: Mail,
      title: 'Email',
      content: 'info@stroycity.ru',
      link: 'mailto:info@stroycity.ru',
      color: '#1e3a5f',
    },
    {
      icon: MapPin,
      title: 'Адрес',
      content: 'Новосибирск, ул. Владимировская, 2/1',
      link: 'https://maps.google.com/?q=Новосибирск, ул. Владимировская, 2/1',
      color: '#e8725c',
    },
    {
      icon: Clock,
      title: 'Режим работы',
      content: 'Пн-Пт: 9:00 - 18:00',
      link: '#',
      color: '#1e3a5f',
    },
  ];

  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-block bg-[#e8725c]/10 text-[#e8725c] px-4 py-2 rounded-full text-sm font-semibold mb-4">
            Связаться с нами
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-[#1e3a5f] mb-4">
            Начните свой проект
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Свяжитесь с нами для консультации и расчета стоимости вашего проекта
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-8 shadow-xl">
              <div className="space-y-6">
                {/* Name */}
                <div>
                  <label htmlFor="name" className="block text-sm font-semibold text-gray-700 mb-2">
                    Имя *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#e8725c] focus:outline-none transition-colors"
                    placeholder="Ваше имя"
                  />
                </div>

                {/* Phone */}
                <div>
                  <label htmlFor="phone" className="block text-sm font-semibold text-gray-700 mb-2">
                    Телефон *
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#e8725c] focus:outline-none transition-colors"
                    placeholder="+7 123 456 78 90"
                  />
                </div>

                {/* Email */}
                <div>
                  <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#e8725c] focus:outline-none transition-colors"
                    placeholder="your@email.com"
                  />
                </div>

                {/* Service */}
                <div>
                  <label htmlFor="service" className="block text-sm font-semibold text-gray-700 mb-2">
                    Услуга
                  </label>
                  <select
                    id="service"
                    name="service"
                    value={formData.service}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#e8725c] focus:outline-none transition-colors"
                  >
                    <option value="">Выберите услугу</option>
                    <option value="commercial">Коммерческое строительство</option>
                    <option value="residential">Жилищное строительство</option>
                    <option value="industrial">Промышленные объекты</option>
                    <option value="reconstruction">Реконструкция</option>
                    <option value="design">Проектирование</option>
                    <option value="general">Генеральный подряд</option>
                  </select>
                </div>

                {/* Message */}
                <div>
                  <label htmlFor="message" className="block text-sm font-semibold text-gray-700 mb-2">
                    Сообщение
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={4}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:border-[#e8725c] focus:outline-none transition-colors resize-none"
                    placeholder="Расскажите о вашем проекте..."
                  ></textarea>
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  className="w-full bg-[#e8725c] text-white px-8 py-4 rounded-lg font-semibold hover:bg-[#d66650] transition-all hover:scale-105 shadow-lg flex items-center justify-center gap-2"
                >
                  Отправить заявку
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </form>
          </motion.div>

          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            {/* Contact Cards */}
            <div className="grid gap-6">
              {contactInfo.map((info, index) => (
                <motion.a
                  key={index}
                  href={info.link}
                  target={info.link.startsWith('http') ? '_blank' : undefined}
                  rel={info.link.startsWith('http') ? 'noopener noreferrer' : undefined}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="group bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all hover:-translate-y-1"
                >
                  <div className="flex items-start gap-4">
                    <div
                      className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: `${info.color}15` }}
                    >
                      <info.icon className="w-6 h-6" style={{ color: info.color }} />
                    </div>
                    <div>
                      <div className="text-sm text-gray-500 mb-1">{info.title}</div>
                      <div className="font-semibold text-[#1e3a5f] group-hover:text-[#e8725c] transition-colors">
                        {info.content}
                      </div>
                    </div>
                  </div>
                </motion.a>
              ))}
            </div>

            {/* Social Links */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="bg-white rounded-xl p-6 shadow-lg"
            >
              <h4 className="font-bold text-[#1e3a5f] mb-4">Мы в социальных сетях</h4>
              <div className="flex gap-4">
                {[
                  { name: 'Telegram', icon: '📱', color: '#0088cc', link: '#' },
                  { name: 'Instagram', icon: '📸', color: '#e8725c', link: '#' },
                  { name: 'VK', icon: '👥', color: '#1e3a5f', link: '#' },
                  { name: 'WhatsApp', icon: '💬', color: '#25D366', link: 'https://wa.me/79139413814' },
                ].map((social, index) => (
                  <a
                    key={index}
                    href={social.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-12 h-12 rounded-lg flex items-center justify-center text-2xl hover:scale-110 transition-transform"
                    style={{ backgroundColor: `${social.color}15` }}
                    title={social.name}
                  >
                    {social.icon}
                  </a>
                ))}
              </div>
            </motion.div>
          </motion.div>
        </div>

        {/* Interactive Google Map */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-16"
        >
          <div className="relative rounded-2xl overflow-hidden shadow-2xl" style={{ height: '500px' }}>
            {/* Google Map Embed */}
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2298.2897464896496!2d82.89842931584584!3d55.01983898033638!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x42dfe5e7e5e5e5e5%3A0x5e5e5e5e5e5e5e5e!2z0YPQuy4g0JLQu9Cw0LTQuNC80LjRgNC-0LLRgdC60LDRjywgMi8xLCDQndC-0LLQvtGB0LjQsdC40YDRgdC6LCDQndC-0LLQvtGB0LjQsdC40YDRgdC60LDRjyDQvtCx0Lsu!5e0!3m2!1sru!2sru!4v1620000000000!5m2!1sru!2sru&maptype=roadmap"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Карта офиса ГК СтройСИТИ"
            ></iframe>

            {/* Overlay with Info */}
            <div className="absolute top-8 left-8 right-8 md:right-auto md:max-w-md">
              <div className="bg-white/95 backdrop-blur-md rounded-2xl p-6 shadow-xl">
                <h3 className="text-2xl font-bold text-[#1e3a5f] mb-4">Посетите наш офис</h3>
                <p className="text-gray-600 mb-4">
                  Приходите к нам для личной консультации. Мы с удовольствием покажем вам 
                  наши завершенные проекты и обсудим ваши идеи за чашкой кофе.
                </p>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-[#e8725c] mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-semibold text-[#1e3a5f]">Новосибирск, ул. Владимировская, 2/1</div>
                      <div className="text-sm text-gray-500">Центр города, рядом с площадью Ленина</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-[#e8725c] flex-shrink-0" />
                    <a href="tel:+79139413814" className="font-semibold text-[#1e3a5f] hover:text-[#e8725c] transition-colors">
                      +7 913 941 38 14
                    </a>
                  </div>
                  <div className="flex items-center gap-3">
                    <Clock className="w-5 h-5 text-[#e8725c] flex-shrink-0" />
                    <div className="text-sm text-gray-600">
                      Пн-Пт: 9:00 - 18:00 | Сб: 10:00 - 15:00
                    </div>
                  </div>
                </div>
                <a
                  href="https://maps.google.com/?q=Новосибирск, ул. Владимировская, 2/1"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-4 inline-block bg-[#e8725c] text-white px-6 py-3 rounded-lg font-semibold hover:bg-[#d66650] transition-all"
                >
                  Построить маршрут
                </a>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
