import { motion } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Shield, Target, Users, Lightbulb } from 'lucide-react';
import logo from 'figma:asset/4be72b4eb8877c8649881e98e554b4d69e7ddd7c.png';

export function About() {
  const values = [
    {
      icon: Shield,
      title: 'Надежность',
      description: 'Гарантируем качество и соблюдение всех стандартов',
    },
    {
      icon: Target,
      title: 'Точность',
      description: 'Выполняем проекты в срок и в рамках бюджета',
    },
    {
      icon: Users,
      title: 'Команда',
      description: 'Профессионалы с многолетним опытом работы',
    },
    {
      icon: Lightbulb,
      title: 'Инновации',
      description: 'Используем современные технологии и материалы',
    },
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Side - Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-block bg-[#e8725c]/10 text-[#e8725c] px-4 py-2 rounded-full text-sm font-semibold mb-6">
              О компании
            </div>
            
            <h2 className="text-4xl md:text-5xl font-bold text-[#1e3a5f] mb-6">
              Строим с 2010 года
            </h2>

            <div className="space-y-4 text-gray-600 mb-8">
              <p className="text-lg">
                <strong className="text-[#1e3a5f]">ГК СтройСИТИ</strong> — ведущая строительная компания 
                Новосибирска, специализирующаяся на комплексном строительстве жилых, 
                коммерческих и промышленных объектов.
              </p>
              <p>
                За 14 лет работы мы реализовали более 500 проектов, заслужив доверие 
                тысяч клиентов. Наша команда профессионалов применяет передовые технологии 
                и следует международным стандартам качества.
              </p>
              <p>
                Мы гордимся тем, что каждый наш проект становится частью городского 
                ландшафта и служит людям долгие годы. Ваше доверие — наша главная награда.
              </p>
            </div>

            {/* Values Grid */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              {values.map((value, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-gradient-to-br from-gray-50 to-white border border-gray-100 rounded-xl p-4 hover:shadow-lg transition-all"
                >
                  <div className="w-10 h-10 bg-[#e8725c]/10 rounded-lg flex items-center justify-center mb-3">
                    <value.icon className="w-5 h-5 text-[#e8725c]" />
                  </div>
                  <h4 className="font-bold text-[#1e3a5f] mb-1">{value.title}</h4>
                  <p className="text-sm text-gray-600">{value.description}</p>
                </motion.div>
              ))}
            </div>

            {/* CTA */}
            <div className="flex flex-wrap gap-4">
              <button
                onClick={() => {
                  const element = document.querySelector('#projects');
                  if (element) element.scrollIntoView({ behavior: 'smooth' });
                }}
                className="bg-[#1e3a5f] text-white px-8 py-3 rounded-lg font-semibold hover:bg-[#152d47] transition-all hover:scale-105"
              >
                Наши проекты
              </button>
              <button
                onClick={() => {
                  const element = document.querySelector('#contact');
                  if (element) element.scrollIntoView({ behavior: 'smooth' });
                }}
                className="border-2 border-[#1e3a5f] text-[#1e3a5f] px-8 py-3 rounded-lg font-semibold hover:bg-[#1e3a5f] hover:text-white transition-all"
              >
                Связаться
              </button>
            </div>
          </motion.div>

          {/* Right Side - Images */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            {/* Main Image */}
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1748956628042-b73331e0b479?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBjb25zdHJ1Y3Rpb24lMjBzaXRlJTIwd29ya2Vyc3xlbnwxfHx8fDE3NzAyNjUyMTd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Construction Team"
                className="w-full h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1e3a5f]/50 to-transparent"></div>
            </div>

            {/* Floating Elements */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="absolute -bottom-8 -left-8 bg-white rounded-2xl p-6 shadow-2xl"
            >
              <div className="flex items-center gap-4">
                <img src={logo} alt="Logo" className="w-16 h-16" />
                <div>
                  <div className="text-3xl font-bold text-[#e8725c]">14+</div>
                  <div className="text-sm text-gray-600">лет опыта</div>
                </div>
              </div>
            </motion.div>

            {/* Stats Card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.5 }}
              className="absolute -top-8 -right-8 bg-[#e8725c] text-white rounded-2xl p-6 shadow-2xl"
            >
              <div className="text-center">
                <div className="text-3xl font-bold mb-1">500+</div>
                <div className="text-sm">проектов</div>
              </div>
            </motion.div>

            {/* Pattern Overlay */}
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full h-full opacity-5 pointer-events-none">
              <div
                className="w-full h-full"
                style={{
                  backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%231e3a5f' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
                }}
              ></div>
            </div>
          </motion.div>
        </div>

        {/* Achievements */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-6"
        >
          {[
            { number: '500+', label: 'Проектов', icon: '🏗️' },
            { number: '1200+', label: 'Клиентов', icon: '👥' },
            { number: '250K+', label: 'М² построено', icon: '📐' },
            { number: '98%', label: 'Довольны', icon: '⭐' },
          ].map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
              className="bg-gradient-to-br from-[#1e3a5f] to-[#152d47] text-white rounded-xl p-6 text-center hover:scale-105 transition-transform"
            >
              <div className="text-4xl mb-3">{stat.icon}</div>
              <div className="text-3xl font-bold mb-2">{stat.number}</div>
              <div className="text-sm opacity-90">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}