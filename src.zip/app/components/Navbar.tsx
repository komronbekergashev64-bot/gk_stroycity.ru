import { useState } from 'react';
import { Menu, X, Phone } from 'lucide-react';
import logo from 'figma:asset/4be72b4eb8877c8649881e98e554b4d69e7ddd7c.png';

interface NavbarProps {
  scrolled: boolean;
}

export function Navbar({ scrolled }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { name: 'Главная', href: '#hero' },
    { name: 'Услуги', href: '#services' },
    { name: 'Проекты', href: '#projects' },
    { name: 'О нас', href: '#about' },
    { name: 'Контакты', href: '#contact' },
  ];

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white shadow-lg py-3' : 'bg-white/95 backdrop-blur-md py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => scrollToSection('#hero')}>
            <img src={logo} alt="СтройСИТИ" className="h-12 w-12" />
            <div>
              <div className="text-xl font-bold text-[#1e3a5f]">СтройСИТИ</div>
              <div className="text-xs text-gray-600">Группа Компаний</div>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <button
                key={link.name}
                onClick={() => scrollToSection(link.href)}
                className="text-gray-700 hover:text-[#1e3a5f] font-medium transition-colors relative group"
              >
                {link.name}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#e8725c] group-hover:w-full transition-all duration-300"></span>
              </button>
            ))}
          </div>

          {/* CTA Button */}
          <div className="hidden md:flex items-center gap-4">
            <a
              href="tel:+79139413814"
              className="flex items-center gap-2 text-gray-700 hover:text-[#1e3a5f] transition-colors"
            >
              <Phone className="w-4 h-4" />
              <span className="font-semibold">+7 913 941 38 14</span>
            </a>
            <button
              onClick={() => scrollToSection('#contact')}
              className="bg-[#e8725c] text-white px-6 py-2.5 rounded-lg font-semibold hover:bg-[#d66650] transition-all hover:scale-105 shadow-lg"
            >
              Связаться
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden text-gray-700 hover:text-[#1e3a5f] transition-colors"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-gray-200 pt-4">
            <div className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <button
                  key={link.name}
                  onClick={() => scrollToSection(link.href)}
                  className="text-left text-gray-700 hover:text-[#1e3a5f] font-medium transition-colors py-2"
                >
                  {link.name}
                </button>
              ))}
              <a
                href="tel:+79139413814"
                className="flex items-center gap-2 text-gray-700 hover:text-[#1e3a5f] transition-colors py-2"
              >
                <Phone className="w-4 h-4" />
                <span className="font-semibold">+7 913 941 38 14</span>
              </a>
              <button
                onClick={() => scrollToSection('#contact')}
                className="bg-[#e8725c] text-white px-6 py-2.5 rounded-lg font-semibold hover:bg-[#d66650] transition-all text-center"
              >
                Связаться
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}