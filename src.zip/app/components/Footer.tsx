import { Phone, Mail, MapPin } from 'lucide-react';
import logo from 'figma:asset/4be72b4eb8877c8649881e98e554b4d69e7ddd7c.png';

export function Footer() {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    services: [
      'Коммерческое строительство',
      'Жилищное строительство',
      'Промышленные объекты',
      'Реконструкция',
      'Проектирование',
      'Генеральный подряд',
    ],
    company: [
      'О компании',
      'Наши проекты',
      'Команда',
      'Карьера',
      'Новости',
      'Контакты',
    ],
  };

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-gradient-to-br from-[#1e3a5f] to-[#152d47] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 lg:py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <img src={logo} alt="СтройСИТИ" className="h-12 w-12" />
              <div>
                <div className="text-xl font-bold">СтройСИТИ</div>
                <div className="text-sm text-blue-200">Группа Компаний</div>
              </div>
            </div>
            <p className="text-blue-200 mb-6 text-sm">
              Профессиональное строительство с 2010 года. Качество, надежность и инновации в каждом проекте.
            </p>
            <div className="flex gap-3">
              {[
                { name: 'Telegram', icon: '📱', link: 'https://t.me/stroycity' },
                { name: 'Instagram', icon: '📸', link: 'https://instagram.com/stroycity' },
                { name: 'VK', icon: '👥', link: 'https://vk.com/stroycity' },
                { name: 'YouTube', icon: '▶️', link: 'https://youtube.com/@stroycity' },
              ].map((social, index) => (
                <a
                  key={index}
                  href={social.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-xl transition-all hover:scale-110"
                  title={social.name}
                >
                  {social.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-bold mb-4">Услуги</h3>
            <ul className="space-y-2">
              {footerLinks.services.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => scrollToSection('#services')}
                    className="text-blue-200 hover:text-white transition-colors text-sm"
                  >
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="text-lg font-bold mb-4">Компания</h3>
            <ul className="space-y-2">
              {footerLinks.company.map((link, index) => (
                <li key={index}>
                  <button
                    onClick={() => {
                      const mapping: { [key: string]: string } = {
                        'О компании': '#about',
                        'Наши проекты': '#projects',
                        'Контакты': '#contact',
                      };
                      scrollToSection(mapping[link] || '#hero');
                    }}
                    className="text-blue-200 hover:text-white transition-colors text-sm"
                  >
                    {link}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-bold mb-4">Контакты</h3>
            <ul className="space-y-3">
              <li>
                <a
                  href="tel:+79139413814"
                  className="flex items-start gap-3 text-blue-200 hover:text-white transition-colors group"
                >
                  <Phone className="w-5 h-5 flex-shrink-0 mt-0.5 text-[#e8725c]" />
                  <span className="text-sm">+7 913 941 38 14</span>
                </a>
              </li>
              <li>
                <a
                  href="mailto:info@stroycity.ru"
                  className="flex items-start gap-3 text-blue-200 hover:text-white transition-colors group"
                >
                  <Mail className="w-5 h-5 flex-shrink-0 mt-0.5 text-[#e8725c]" />
                  <span className="text-sm">info@stroycity.ru</span>
                </a>
              </li>
              <li>
                <div className="flex items-start gap-3 text-blue-200">
                  <MapPin className="w-5 h-5 flex-shrink-0 mt-0.5 text-[#e8725c]" />
                  <span className="text-sm">Новосибирск, ул. Владимировская, 2/1</span>
                </div>
              </li>
            </ul>

            <div className="mt-6 p-4 bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
              <div className="text-sm font-semibold mb-1">Режим работы</div>
              <div className="text-sm text-blue-200">Пн-Пт: 9:00 - 18:00</div>
              <div className="text-sm text-blue-200">Сб: 10:00 - 15:00</div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/20 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-sm text-blue-200 text-center md:text-left">
              © {currentYear} ГК СтройСИТИ. Все права защищены.
            </div>
            <div className="flex flex-wrap justify-center gap-6 text-sm text-blue-200">
              <button className="hover:text-white transition-colors">
                Политика конфиденциальности
              </button>
              <button className="hover:text-white transition-colors">
                Условия использования
              </button>
              <button className="hover:text-white transition-colors">
                Документы
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}